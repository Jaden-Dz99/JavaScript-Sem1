/**
 * Javascript Week 06 - Demo 00
 *
 * Filename: js/demo-00.js
 * Author:   Adrian Gould
 * Date:     2019-03-12
 *
 */

