/**
 * Javascript Week 05 - Demo 03
 *
 * Writing to the DOM
 *
 * Filename: js/demo-03.js
 * Author:   Jaden Dzubiel
 * Date:     2019-03-05
 *
 */

let doc = document;
let titles = doc.getElementsByTagName("title");
let title = titles[0];
// title = doc.getElementsByTagName('titles")[0];
let titleText = title.innerText;
let titleTextLength = titleText.length;
let reversedTitle = "";
for (let index = 0; index < titleTextLength; index++){
    let letter = titleText[index];
    reversedTitle = letter + reversedTitle;
}
title.innerText = reversedTitle;
let before = doc.getElementById("before");
let after = doc.getElementById("after");
before.innerText=titleText;
after.innerText=reversedTitle;
