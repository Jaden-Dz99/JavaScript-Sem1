/**
 * Javascript Week 05 - Exercise 03
 *
 * Filename: js/exercise.js
 * Author:   Jaden Dzubiel
 * Date:     2019-02-26
 *
 */
let doc = document;
let form = doc.querySelector("form");
let givenFruit = doc.getElementById('givenFruit');
let givenPrice = doc.getElementById('givenPrice');
let givenAmount = doc.getElementById('givenAmount');

console.log(form);

form.addEventListener("submit", function (event) {

    console.log("Saving value", form.elements.givenFruit.value);
    console.log("Saving value", form.elements.givenPrice.value);
    console.log("Saving value", form.elements.givenAmount.value);

    doc.getElementById('resultGivenFruit').innerText=form.elements.givenFruit.value;
    doc.getElementById('resultGivenPrice').innerText= "$" + form.elements.givenPrice.value;
    doc.getElementById('resultGivenAmount').innerText=form.elements.givenAmount.value + "kg";

    doc.getElementById('resultTotal').innerText=form.elements.givenFruit.value +
        ": " + form.elements.givenAmount.value + "kg " + "at $" + form.elements.givenPrice.value + "= $"
        + (form.elements.givenAmount.value*form.elements.givenPrice.value);

    event.preventDefault();
});
