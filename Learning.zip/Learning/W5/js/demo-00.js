/**
 * Javascript Week 05 - Demo 00
 *
 * Filename: js/demo-00.js
 * Author:   Jaden Dzubiel
 * Date:     2019-03-05
 *
 */
