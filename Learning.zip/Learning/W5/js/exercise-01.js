/**
 * Javascript Week 05 - Exercise 01
 *
 * Filename: js/exercise-01.js
 * Author:   Jaden Dzubiel
 * Date:     2019-02-26
 *
 */
let doc = document;
let form = doc.querySelector("form");
let givenFarenheit = doc.getElementById('givenFarenheit');

console.log(form);

form.addEventListener("submit", function (event) {

    console.log("Saving value", form.elements.givenFarenheit.value);

    doc.getElementById('resultGivenFarenheit').innerText=form.elements.givenFarenheit.value;
    doc.getElementById('resultGivenCelsius').innerText=((form.elements.givenFarenheit.value-32)*5/9);

    event.preventDefault();
});