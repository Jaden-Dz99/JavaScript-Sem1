/**
 * Javascript Week 05 - Demo 04
 *
 * Filename: js/demo-04.js
 * Author:   Jaden Dzubiel
 * Date:     2019-03-05
 *
 */

let doc = document;
let title = doc.getElementsByTagName("title")[0];
let titleText = title.innerText;
let titleTextLength = titleText.length;
let reversedTitle = reverseString(titleText);
title.innerText = reversedTitle;


let before = doc.getElementById("before");
let after = doc.getElementById("after");
before.innerText=titleText;
after.innerText=reversedTitle;

//reverse text
//console.log(titleText.split(""));
//console.log(titleText.split("").reverse());
//console.log(titleText.split("").reverse().join(""));


