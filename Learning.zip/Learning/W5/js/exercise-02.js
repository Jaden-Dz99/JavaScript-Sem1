/**
 * Javascript Week 05 - Exercise 02
 *
 * Filename: js/exercise-02.js
 * Author:   Jaden Dzubiel
 * Date:     2019-02-26
 *
 */
let doc = document;
var form = doc.querySelector("form");
let givenNumbers = doc.getElementById('givenNumbers');

console.log(form);

form.addEventListener("submit", function (event) {
console.log("Saving value", form.elements.givenNumbers.value);

    let givenNumbersError = doc.getElementById('givenNumbersError');
    let firstResult = doc.getElementById('resultNumbers');
    if (!isEmpty(givenNumbers))
    {
        firstResult.innerText = givenNumbers;
        givenNumbersError.classList.add('d-none');
    }
    else
        {
        givenNumbersError.innerText = "You must enter a number";
        givenNumbersError.classList.remove('d-none')
        }

    var i;
    text = "";
    let n = doc.getElementById('givenNumbers');

    for (i = 1; i <= n; i++)
    {
        text += i+"*";
    }


    var i, fact;
    fact = 1;
    let No = doc.getElementById("givenNumbers").value;

    for (i = 1; i<=No; i++)
    {
        fact = fact*i;
    }

    doc.getElementById('resultNumbers').innerText = "!"+ form.elements.givenNumbers.value + "=" + text;
    doc.getElementById('resultAnswer').innerHTML = fact;
    event.preventDefault();
});