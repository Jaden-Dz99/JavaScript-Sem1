/**
 * Javascript Week 05 - Demo 05
 *
 * Filename: js/demo-05.js
 * Author:   Jaden Dzubiel
 * Date:     2019-02-26
 *
 */

let doc = document;
var form = doc.querySelector("form");
let givenName = doc.getElementById('givenName');
let familyName = doc.getElementById('familyName');
let email = doc.getElementById('email');

console.log(form);

form.addEventListener("submit", function(event) {
    console.log("Saving value", form.elements.givenName.value);
    console.log("Saving value", form.elements.familyName.value);
    console.log("Saving value", form.elements.email.value);

    doc.getElementById('resultGivenName').innerText=form.elements.givenName.value;
    doc.getElementById('resultFamilyName').innerText=form.elements.familyName.value;
    doc.getElementById('resultEmail').innerText=form.elements.email.value;
    // add JS for displaying the family and email addresses on the page

    event.preventDefault();
});