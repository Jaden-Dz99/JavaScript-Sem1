<?php
 /** Created by PhpStorm. */

 //define variables
$postVars = $_POST; //grab the POSTed data from the form
$postVars = $_GET; //grab the GETed data from the form

echo '<h1>POST DATA</h1>';
echo '<pre>';
var_dump($postVars);
echo '</pre>';

echo '<h1>GET DATA</h1>';
echo '<pre>';
var_dump($getVars);
echo '</pre>';
