/**
 * Javascript Week 07 - Demo 01
 *
 * Filename: js/demo-00.js
 * Author:   Jaden Dzubiel
 * Date:     2019-03-19
 *
 */

