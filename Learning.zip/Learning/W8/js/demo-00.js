/**
 * Javascript Week 07 - Demo 00
 *
 * Filename: js/demo-00.js
 * Author:   Adrian Gould
 * Date:     2019-03-19
 *
 */

